---
name: cadency-ado-testcase-workflow
description: Generate Cadency manual QA test cases from Azure DevOps user stories into the existing VSTS Excel template, pause for user review, then upload the reviewed workbook into a specified Azure DevOps test plan and suite through Azure DevOps MCP. Also use this skill to read an existing Cadency test case by ID and extract title, area path, iteration path, manual steps, and linked work items.
---

# Cadency ADO Testcase Workflow

Use this skill when the user wants any of these:

- fetch a Cadency user story or work item by ID and generate manual QA test cases in `.xlsx` only
- use the existing VSTS Excel template instead of creating a new spreadsheet shape
- review or edit the generated workbook before upload
- upload a reviewed workbook into a specific Azure DevOps test plan and suite
- read an existing Cadency test case by ID and extract structured details

## Core rules

- Work like a 7+ years experienced manual QA engineer. Keep cases realistic, targeted, and non-generic.
- Use Azure DevOps MCP for Azure DevOps reads and writes. If the ADO tools are not already exposed in the tool list, discover them with `tool_search`.
- Default Azure DevOps project is `Cadency` unless the user explicitly provides a different project.
- Treat the story or work item as the binding source of truth. Use only supported evidence such as title, description, acceptance criteria, attachments, and requirement-bearing linked items.
- Do not invent validations, defaults, workflow behavior, field names, transitions, or outcomes that are not supported by story evidence.
- If a required detail is missing, write `Needs clarification` instead of guessing.
- Generate `.xlsx` only.
- Do not upload immediately after generation. Stop after creating the workbook, show the file path, and wait for user approval or a user-provided edited filename.
- If the user later provides a filename, read that workbook and upload from that file instead of regenerating.
- Keep all IDs dynamic. Never hardcode story IDs, test plan IDs, suite IDs, or test case IDs into the workflow.
- Treat any IDs or filenames shown in examples as placeholders only. Always use the values from the current user request.
- Treat all workflow inputs as runtime values from the current request, including story IDs, plan IDs, suite IDs, test case IDs, workbook filenames, output locations, and project names.
- If a required runtime input is missing, ask for that specific input instead of guessing or silently defaulting to a different story, suite, file, or target.
- Preserve user edits in the reviewed workbook. Do not regenerate or overwrite them unless the user asks.

## Local context

Read [references/local-files.md](references/local-files.md) when you need exact local paths, template headers, workbook row shape, or existing Cadency repo reference locations.

## Workflow decision

- If the user provides a user story or work item ID, use the story-to-workbook lane.
- If the user provides an existing workbook filename or asks to upload reviewed test cases, use the reviewed-workbook upload lane.
- If the user provides an Azure DevOps test case ID, use the test-case extraction lane.

## Lane 1: Story to reviewed workbook

1. Collect the minimum inputs:
   - story or work item ID
   - target test plan ID
   - target suite ID
   - optional output directory if the user wants a specific location
2. Fetch the work item through Azure DevOps MCP and inspect:
   - title
   - description
   - acceptance criteria
   - attachments or reproduction details if present
   - requirement-bearing linked items
3. If the request is tied to `AdoMCPtestcasesUpload`, read its local instructions and reference knowledge files listed in `references/local-files.md`.
4. Draft manual QA test cases from the story evidence only.
5. Build the workbook in the exact template shape:
   - keep the header order unchanged
   - each new test case starts with a row containing `Title` and metadata columns
   - following rows for that test case carry `Step Action` and `Step Result`
6. Save the workbook:
   - prefer an existing `generated-testcases/` folder in the active project
   - otherwise use `<cwd>/generated-testcases/`
   - use a story-based filename such as `TestCases_<storyId>_<timestamp>.xlsx`
7. Return the saved file path and stop. Tell the user the file is ready for review and that upload will wait for approval or an edited filename.

## Lane 2: Upload reviewed workbook

1. Require:
   - test plan ID
   - suite ID
   - workbook filename or absolute path
2. Read the workbook and parse test cases by template shape:
   - the first row is the fixed header row
   - a non-empty `Title` cell starts a new test case
   - following blank-title rows belong to the current test case until the next title row
3. Use the reviewed workbook as the upload source. Do not rewrite the workbook first unless the user asks.
4. For each test case, upload through Azure DevOps MCP:
   - create the test case work item
   - map manual steps into Azure DevOps manual step format
   - keep required story linkage only when explicitly requested or when the local Cadency flow already expects it
5. Add the created test cases to the specified Cadency test plan and suite.
6. Return:
   - created test case IDs
   - uploaded file path
   - target test plan ID and suite ID
   - any partial failures or skipped rows

## Lane 3: Existing test case extraction

1. Require the Azure DevOps test case ID.
2. Read the test case from project `Cadency` through Azure DevOps MCP.
3. Extract and return:
   - title
   - area path
   - iteration path
   - manual steps
   - related work item links
4. Highlight any story linked through `Tested By`, `Related`, or equivalent relation names when present.
5. Prefer structured output:
   - brief summary
   - flat list of extracted fields
   - related-item list with relation type and work item ID

## Excel template rules

- Match the workbook header exactly. See `references/local-files.md` for the current header row.
- Preserve the template columns even when some metadata cells are blank.
- `Step Result` must describe the expected result for that specific step, not repeat the test case title.
- Keep actions and results concrete, reproducible, and verifiable.
- Avoid generic filler test cases.
- If story evidence is too thin to support a field value, leave the workbook cell blank or use `Needs clarification` when that is clearer than silence.

## Reference usage

- Use local Cadency reference suites and knowledge only as pattern sources for testcase shape, wording, scheduler flow, and coverage cues.
- Reference material must not override the current story.
- If a reference pattern conflicts with the story, follow the story and note the gap as clarification.

## Example triggers

- `Generate reviewed testcases in xlsx for story <storyId> and target plan <testPlanId> suite <suiteId>.`
- `Upload this reviewed workbook to plan <testPlanId> suite <suiteId>: C:\path\to\file.xlsx`
- `Read Cadency test case <testCaseId> and extract title, area path, iteration path, steps, and linked story details.`
