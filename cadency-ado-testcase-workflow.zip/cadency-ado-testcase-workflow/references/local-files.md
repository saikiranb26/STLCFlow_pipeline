# Local files

Use this file only when you need exact machine-local paths, workbook shape details, or the existing Cadency repo references.

## Template workbook

- Path: `C:\Users\bsaikiran\Azuretestcases upload\Referencetemp\Template VSTS.xlsx`
- Current workbook sheet: `Sheet1`
- Current header row, in order:
  - `Title`
  - `Step Action`
  - `Step Result`
  - `Assigned to`
  - `State`
  - `Product Release`
  - `Component`
  - `Automation Status`
  - `New priority`
  - `Estimated Manual testing time`

## Workbook row shape

- The first row is the fixed header row.
- A test case starts with a row where `Title` is populated.
- That title row also carries the metadata columns.
- The title row usually leaves `Step Action` and `Step Result` empty.
- The following rows for the same test case keep `Title` blank and fill `Step Action` plus `Step Result`.
- A new non-empty `Title` starts the next test case.

## Existing Cadency testcase flow repo

- Repo root: `C:\Users\bsaikiran\AdoMCPtestcasesUpload`
- Repo instructions: `C:\Users\bsaikiran\AdoMCPtestcasesUpload\AGENTS.md`
- Generated workbook folder commonly used by that repo:
  - `C:\Users\bsaikiran\AdoMCPtestcasesUpload\generated-testcases`
- Reference suite registry:
  - `C:\Users\bsaikiran\AdoMCPtestcasesUpload\references\source-register.md`
- Recurring-task extracted knowledge:
  - `C:\Users\bsaikiran\AdoMCPtestcasesUpload\knowledge\cadency-plan-191930-recurring-user-reference-knowledge.json`

## Existing MCP/reference project folder

- Actual local path:
  - `C:\Users\bsaikiran\GitHubCoPilotBestPractices`
- The user may refer to `GitHubCoPilotBestPractices - Copy`, but on this machine the folder currently present is the path above.

## Azure DevOps MCP config reference

- Codex config path:
  - `C:\Users\bsaikiran\.codex\config.toml`
- Current local configuration uses default project `Cadency`.
- Do not echo secrets or token values from config files into responses.
