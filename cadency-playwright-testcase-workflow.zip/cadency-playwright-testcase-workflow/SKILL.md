---
name: cadency-playwright-testcase-workflow
description: Generate Playwright-assisted Cadency manual QA test cases from Azure DevOps stories using browser-driven UI evidence, pause for workbook review, upload the approved workbook into a target Azure DevOps plan and suite, and execute uploaded test cases step-by-step through Playwright with real pass/fail updates in Azure DevOps.
---

# Cadency Playwright Testcase Workflow

Use this skill when the user wants any of these:

- generate Cadency testcases with Playwright-assisted UI evidence
- use a runtime navigation path such as `Login into application > dashboard > tasks > scheduler`
- review the generated workbook before upload
- upload the reviewed Playwright-assisted workbook into a specific test plan and suite
- execute uploaded testcases through Playwright and update pass/fail in Azure DevOps

## Core rules

- Work like a 7+ years experienced automation engineer.
- Keep this skill separate from the ADO-only testcase skill. Use this one only for the Playwright branch.
- Use the existing Playwright branch in `AdoMCPtestcasesUpload` instead of inventing a new flow.
- Use Playwright MCP for browser-assisted inspection and evidence collection when the task calls for Playwright-guided analysis.
- Default Azure DevOps project is `Cadency` unless the user explicitly gives a different project.
- Treat any IDs, suite IDs, plan IDs, filenames, and navigation paths shown in examples as placeholders only. Always use the values from the current user request.
- `NavigationPath` is mandatory for Playwright generation and execution. Never rely on a hardcoded default.
- The navigation path is dynamic and may change for every request, story, module, or feature area.
- Do not assume `scheduler` or any other fixed module name unless the current user input explicitly says so.
- Always pass the exact current navigation path into the Playwright branch command at runtime.
- Story evidence remains the binding source of truth. Playwright evidence is a supporting source for visible controls, labels, defaults, validations, and page flow.
- If UI behavior conflicts with story evidence, do not guess. Call out the conflict and require clarification.
- Generate `.xlsx` only.
- Do not upload immediately after generation. Stop after creating the workbook, show the saved file path, and wait for user review or an edited filename.
- Preserve user edits in the reviewed workbook. Do not overwrite them unless the user explicitly asks.
- For execution, run testcases by actual test steps and actual observed browser behavior only.
- For execution, rely on real browser-driven automation from the existing Playwright branch. Do not present inferred or manually imagined outcomes as Playwright results.
- Do not mark pass based on assumption, inference, or a guessed happy path.
- If a testcase cannot be executed from the available steps, evidence, or application state, mark it failed or blocked with a concrete reason instead of hallucinating completion.
- Pass/fail updates in Azure DevOps must come from real Playwright execution results.

## Local context

Read [references/local-files.md](references/local-files.md) when you need exact repo paths, wrapper commands, config locations, evidence folders, or output locations.

## Workflow decision

- If the user gives a story ID and asks for generation, use the generation lane.
- If the user gives a reviewed workbook path and wants upload, use the upload lane.
- If the user asks to run or validate uploaded testcases in the UI, use the execution lane.
- If the user wants the whole lifecycle, still keep the review gate between generation and upload unless the user explicitly asks for non-interactive upload.

## Lane 1: Evidence-driven generation

1. Collect the minimum inputs:
   - story ID
   - suite ID
   - test plan ID
   - navigation path
   - optional project name
   - optional output directory
2. Use the existing Playwright branch flow:
   - collect browser-driven UI evidence first
   - then generate the testcase workbook using that evidence plus story evidence
3. Prefer the existing wrapper flow in the local repo rather than rebuilding it manually.
4. Default staged command pattern:
   - `.\ADOTCCompleteWorkFlow-Playwright.ps1 -StoryId <storyId> -SuiteId <suiteId> -TestPlanId <testPlanId> -NavigationPath "<path>" -GenerateOnly`
5. After generation:
   - return the workbook path
   - point the user to the generated file for review
   - stop and wait for approval or an edited filename

### Navigation path handling

- Treat the navigation path as request-specific input.
- Support different module paths such as task flows, reports, match screens, exports, imports, configuration pages, or any other user-provided path.
- If the user gives the navigation path, use it exactly.
- If the user does not give a navigation path and the Playwright branch needs one, ask for it instead of guessing.
- If story evidence suggests a likely path but the user did not provide one, treat that as a suggestion only, not as confirmed runtime input.

## Lane 2: Upload reviewed workbook

1. Require:
   - story ID
   - suite ID
   - test plan ID
   - reviewed workbook path, if the user edited a specific file
2. Use the reviewed workbook as the upload source.
3. Prefer the Playwright upload branch already present in the repo.
4. Non-interactive upload should only happen after the user explicitly approves it.
5. Preferred upload command pattern:
   - `.\ADOTCCompleteWorkFlow-Playwright.ps1 -StoryId <storyId> -SuiteId <suiteId> -TestPlanId <testPlanId> -UploadOnly -ApproveUpload yes`
6. Return:
   - uploaded workbook path
   - created test case IDs if available
   - target plan and suite
   - any upload failures

## Lane 3: Real Playwright execution

1. Require:
   - story ID when available
   - suite ID
   - test plan ID
   - navigation path
   - optional `headless` preference
2. Execute only against uploaded Azure DevOps testcases for the target suite.
3. Use the existing Playwright execution branch in the repo.
4. Preferred execution command pattern:
   - `.\ADOTCCompleteWorkFlow-Playwright.ps1 -StoryId <storyId> -SuiteId <suiteId> -TestPlanId <testPlanId> -NavigationPath "<path>" -ExecuteOnly`
5. Execution standards:
   - derive actions from testcase steps and supported story or Playwright evidence
   - use real UI navigation and real validations
   - take failures from observed browser outcomes, validation messages, missing UI, blocked saves, failed runs, or unsupported state
   - never convert uncertainty into a pass
6. Azure DevOps update rules:
   - publish pass or fail results back to Azure DevOps
   - include concrete execution comments
   - update testcase state only through the supported branch behavior
7. Return:
   - passed count
   - failed count
   - blocked count if present
   - execution output directory
   - Azure DevOps result update summary

## Full-flow default

When the user asks for the complete Playwright workflow, default to the safer staged approach:

1. generate with Playwright evidence
2. pause for workbook review
3. upload only after approval
4. execute only after upload

Do not collapse these into a single blind run unless the user explicitly wants that.

## Quality bar for generated testcases

- Keep steps aligned to the actual target module flow for the current navigation path.
- Use story evidence first and Playwright UI evidence second.
- Keep `Step Result` specific to the exact action performed.
- Avoid unrelated navigation or setup copied from other modules.
- Avoid generic filler cases.
- If the story is thin, use `Needs clarification` rather than making up validations or outcomes.

## Quality bar for execution

- Treat the uploaded testcase steps as the execution contract.
- Execute step-by-step rather than summarizing broad feature behavior.
- If the current execution branch supports only certain testcase patterns, be explicit about unsupported patterns instead of pretending they ran.
- Record observable reasons for failure such as:
  - field validation appeared
  - expected control was missing
  - save did not succeed
  - run did not complete
  - login did not progress
  - Playwright evidence for the target story was missing

## Example triggers

- `Generate Playwright-assisted reviewed testcases for story <storyId> in suite <suiteId> and plan <testPlanId> using navigation path "<path>".`
- `Upload the reviewed Playwright workbook for story <storyId> to plan <testPlanId> suite <suiteId>.`
- `Execute the uploaded Playwright testcases for story <storyId> in suite <suiteId> and update pass fail in ADO using navigation path "<path>".`
