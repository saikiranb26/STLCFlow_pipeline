# Local files

Use this file only when you need exact local paths, wrapper commands, or Playwright branch output locations.

## Repo root

- `C:\Users\bsaikiran\AdoMCPtestcasesUpload`

## Primary repo instructions

- `C:\Users\bsaikiran\AdoMCPtestcasesUpload\AGENTS.md`

## Playwright wrapper entrypoint

- `C:\Users\bsaikiran\AdoMCPtestcasesUpload\ADOTCCompleteWorkFlow-Playwright.ps1`

## Preferred staged commands

- Generate only:
  - `.\ADOTCCompleteWorkFlow-Playwright.ps1 -StoryId <storyId> -SuiteId <suiteId> -TestPlanId <testPlanId> -NavigationPath "<path>" -GenerateOnly`
- Upload only after approval:
  - `.\ADOTCCompleteWorkFlow-Playwright.ps1 -StoryId <storyId> -SuiteId <suiteId> -TestPlanId <testPlanId> -UploadOnly -ApproveUpload yes`
- Execute only:
  - `.\ADOTCCompleteWorkFlow-Playwright.ps1 -StoryId <storyId> -SuiteId <suiteId> -TestPlanId <testPlanId> -NavigationPath "<path>" -ExecuteOnly`

## Underlying npm entrypoints

- `npm run auto:testcases:playwright -- <storyId> --suite-id=<suiteId> --test-plan-id=<testPlanId> --project=<project> --navigation="<path>"`
- `npm run upload:testcases:playwright -- <storyId> <suiteId> --test-plan-id=<testPlanId>`
- `npm run execute:testcases:playwright -- --suite-id=<suiteId> --story-id=<storyId> --test-plan-id=<testPlanId> --project=<project> --navigation="<path>" --mark-ready`

## Playwright config files

- Workflow defaults:
  - `C:\Users\bsaikiran\AdoMCPtestcasesUpload\config\playwright-workflow-config.json`
- Playwright MCP config:
  - `C:\Users\bsaikiran\AdoMCPtestcasesUpload\.vscode\playwright-mcp.config.json`
- Codex config with MCP server entries:
  - `C:\Users\bsaikiran\.codex\config.toml`

## Generated workbook and evidence locations

- Generated workbooks:
  - `C:\Users\bsaikiran\AdoMCPtestcasesUpload\generated-testcases`
- Playwright evidence root:
  - `C:\Users\bsaikiran\AdoMCPtestcasesUpload\evidence\playwright`
- Execution output root:
  - `C:\Users\bsaikiran\AdoMCPtestcasesUpload\execution-results`

## Browser profile and session locations

- Playwright MCP profile/output are configured under:
  - `.playwright-mcp/profile`
  - `.playwright-mcp/output`
- Local execution branch also uses:
  - `.playwright-ui/profile`
  - `.playwright-ui/auth-state.json`

## Important branch behavior

- Navigation path is required for Playwright generation and execution.
- Default browser mode is headed Chrome unless headless is explicitly requested.
- The wrapper pauses for review before upload when used in `-GenerateOnly` mode.
- Execution publishes pass or fail results back to Azure DevOps and completes a test run.
- The execution branch is designed to use actual observed UI outcomes and failure details; it should not be treated as a generic "assume pass" runner.
