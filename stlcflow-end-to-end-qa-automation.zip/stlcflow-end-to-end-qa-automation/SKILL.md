---
name: stlcflow-end-to-end-qa-automation
description: >-
  Run the STLCFlow end-to-end Cadency QA pipeline inside the STLCFlow project:
  analyze a dynamic Azure DevOps work item, mine recursive reference suites,
  generate realistic manual testcases in the user's Excel template, pause for
  review, upload the approved workbook to a target plan and suite, generate BDD
  Playwright TypeScript automation in the project framework, execute only the
  current uploaded ADO cases, publish ADO results and Allure artifacts, and use
  Chrome DevTools MCP only as a secondary debugging layer. Use when the user
  asks to operate or resume the STLCFlow project or wants one skill to govern
  generation, upload, automation, execution, debugging, and reporting for
  Cadency stories.
---

# STLCFlow End To End QA Automation

Use this skill for the full `STLCFlow` lifecycle inside `C:\Users\bsaikiran\STLCFlow`.

## Core rules

- Work like a 10+ years experienced SDET with equal rigor in manual and automation testing.
- Treat the current `workItemId`, `suiteId`, and `testPlanId` from the current request as the only active run context.
- Never reuse an older story, workbook, uploaded suite, manifest, or execution state when the current run IDs differ.
- Use Azure DevOps MCP as the primary system of record for work items, plans, suites, testcase reads, and testcase uploads.
- Use Playwright as the primary browser execution layer.
- Use Chrome DevTools MCP only as a secondary layer for locator help, DOM inspection, network or console diagnosis, and debugging.
- Generate new testcases from the current story and reference knowledge. Never copy-paste old testcase content unless the user explicitly asks.
- Preserve the user's workbook review gate. Do not upload or automate from an unapproved draft.
- Generate automation from the approved workbook only.
- Persist automation code in the STLCFlow framework after generation and execution. Do not keep automation logic only in transient run state.
- Execute only the current uploaded ADO cases for the current `workItemId`, `suiteId`, and `testPlanId`.
- Publish only real execution outcomes. Never guess pass, fail, or blocked results.
- If a scenario still contains unsupported fallback steps, do not execute it. Fix inference or POM support first.
- If the user stops a run, stop the STLCFlow and Playwright process tree before any rerun.

## Read local references only when needed

Read [references/local-files.md](references/local-files.md) when you need:

- project root and artifact locations
- wrapper and npm command entrypoints
- workbook folder conventions
- story artifact file locations
- shared automation framework locations
- current project requirements and decision files

## Runtime inputs

Collect only the inputs needed for the requested stage:

- `workItemId`
- `suiteId`
- `testPlanId`
- optional approved workbook path when the user already reviewed a file
- optional project name if different from `Cadency`
- optional explicit mode such as generate only, upload only, execute only, or full flow

Do not require a navigation path by default for this project. Prefer deriving the execution path from the approved workbook, current uploaded ADO cases, story evidence, and the project framework. Ask only when the entry path is genuinely ambiguous and cannot be derived safely.

## Source of truth order

Follow this order strictly:

1. current request IDs and mode
2. current approved workbook
3. current uploaded ADO testcases for the target suite and plan
4. current story evidence
5. recursive reference knowledge from the configured parent plans and suites
6. Playwright evidence
7. Chrome DevTools evidence

If any lower-priority source conflicts with a higher-priority source, follow the higher-priority source and record the conflict.

## Persistent knowledge rule for every new story

Whenever the user provides a new story/work item ID, analyze all available STLCFlow knowledge before testcase generation:

1. Read the current ADO story first, including title, description, acceptance criteria, comments, attachments, linked work items, and related bugs.
2. Read local Match knowledge from the project `knowledge` folder:
   - `knowledge/match-help/README.md`
   - `knowledge/match-help/match-help-page-index.json`
   - relevant `knowledge/match-help/*.md` functionality files based on story keywords/module hints
   - `knowledge/match-application-reference-analysis.md`
   - `knowledge/ado-direct-coverage-status.md`
   - `knowledge/latest-release-recurring-patterns.md`
   - `knowledge/reference-roots.ado.json`
   - `knowledge/reference-suite-corpus.json`
   - `knowledge/reference-harvest-status.json`
3. Use the previously provided recursive reference roots as background knowledge:
   - Master Regression plan `6357`, Match Angular suite root `70798`
   - Match Angular manual root `164203`
   - Match Angular automation root `122298`
   - Match Smoke Tests suite root `171004`
   - TDL suite root `149176`
   - Latest Release Match plan `191930`
4. Treat these sources as domain behavior, coverage, and writing-style references only. The current story remains the source of truth.
5. Generate fresh manual testcases in the user's referenced Excel template and the user's observed testcase writing style. Do not copy old testcase content verbatim.
6. Make every testcase concrete enough for later automation: clear preconditions, actions, expected results, data state, navigation path, permissions, and observable outcomes.
7. Save the generated workbook under the project generated Excel folder and stop for user review before upload or automation.

## Agent instructions for this process

### Story Agent

- Always start from the current ADO story and active `workItemId`, `suiteId`, and `testPlanId`.
- Infer the Match functional area from story text, then read the relevant Match Help functionality file(s) plus the ADO reference corpus.
- Use regression, smoke, latest-release, and TDL roots only for coverage ideas, module behavior, and the user's testcase writing style.
- Generate the manual testcase workbook in the referenced VSTS Excel template, using fresh story-specific cases.
- Include positive, negative, validation, permission, navigation/state-retention, data-state, and regression scenarios when relevant.

### Scenario Exploration Agent

- Use Match Help and story context to identify likely application screens, dashboards, menus, dialogs, grids, and workflows.
- Prefer requirement-first planning when no navigation path is supplied; do not invent unverified UI labels.
- When browser evidence is needed, collect only current-story evidence and keep it traceable to the story, suite, and plan.

### Locator Agent

- Use Match Help screen names and generated manual steps to plan stable locator boundaries for pages, dialogs, grids, rows, filters, buttons, and messages.
- Prefer accessible/user-facing Playwright locators, then stable attributes, then scoped text fallbacks.
- Record locator uncertainty and block execution if the page object cannot support a required action safely.

### Framework Agent

- Generate automation only after the reviewed workbook is approved and uploaded testcase IDs are mapped.
- Keep story-specific feature files, step definitions, page classes, data files, manifests, traceability, and reports separated by the story folder name.
- Reuse existing framework helpers and page objects where possible; add story-specific POM support only where the approved workbook requires it.
- Do not execute unsupported fallback steps.

### Maintenance Agent

- Execute only the current uploaded testcase set for the active story, suite, and plan.
- Publish only real Playwright outcomes to ADO.
- Store execution summaries, screenshots, traces, logs, Allure output, and failure classifications in the current story folder.
- Use failures to identify product bugs, environment/data issues, or automation gaps before changing framework code.

## Playwright BDD Cucumber POM TypeScript rules

Apply these rules to every generated or edited automation file:

1. Keep feature files business-readable. Feature text must describe user behavior and business outcome, not selectors, XPath, CSS, or implementation details.
1a. Do not append story IDs, suite IDs, plan IDs, or internal traceability text to visible Given/When/Then step text. Keep those IDs in tags, manifests, scenario data, reports, and ADO mappings instead. Match the original framework style under `C:\Users\bsaikiran\playwright automation orginal`.
2. Follow this execution flow strictly: Feature file -> Step definition -> Page object -> Playwright action.
3. Never put locators or Playwright `page.locator(...)` calls inside step definitions. Step definitions must call page-object or shared scenario-runner methods only.
4. Keep all locators inside page-object files, component-object files, or dedicated locator modules.
5. Keep step definitions thin. They should load test data, call page-object methods, and perform high-level orchestration only.
6. Use Playwright recommended locators first: `getByRole`, `getByLabel`, `getByText`, `getByPlaceholder`, and `getByTestId`.
7. Avoid brittle XPath and long CSS selectors. Use them only as documented fallbacks inside page objects when accessible locators are not available.
8. Do not use hard waits such as `waitForTimeout` in new automation. Use Playwright assertions, locator waits, load-state waits, or condition-based polling.
9. Do not use `networkidle` as a page-readiness signal for Cadency flows. Background requests can keep the app busy and create false red report substeps even when the scenario passes.
10. Create one page object per page or major component, such as `LoginPage`, `DashboardPage`, `UserManagementPage`, `HeaderComponent`, or `TableComponent`.
11. Keep page-object methods reusable, for example `login`, `logout`, `searchUser`, `selectDropdownValue`, `expectLoaded`, and `expectDashboardVisible`.
12. Keep business assertions mainly in `Then` steps. Page objects may contain reusable technical validations such as `expectLoaded`.
13. Use the framework fixture/world objects for shared state: page, context, page objects, runtime config, test data, and scenario state.
14. Use hooks for setup, cleanup, and evidence. Capture screenshots, traces, video, and logs on failure or when needed for debugging.
15. Use tags consistently, such as `@smoke`, `@regression`, `@ui`, `@api`, `@critical`, `@story-<id>`, `@suite-<id>`, `@plan-<id>`, and `@tc-<id>`.
16. Keep test data separate from step definitions. Use JSON files, fixtures, environment variables, builders, or runtime config.
17. Use environment-based configuration for base URL, username, password, browser, headless mode, and timeouts.
18. Avoid duplicate step definitions. Reuse common domain steps, but do not make steps too generic or too technical.
19. Use TypeScript types for page objects, fixtures/world objects, method parameters, generated scenario state, and test data models.
20. Keep naming consistent: `login.feature`, `login.steps.ts`, `LoginPage.ts`; methods such as `login`, `logout`, `searchUser`, and `expectDashboardVisible`.
21. Keep scenarios independent. Each scenario must prepare or create its own state and must not depend on execution order.
22. Use isolated browser contexts per scenario. Use storage state only for login optimization, never to hide scenario dependencies.
23. Keep CI stable. Run smoke separately from regression, and retry only infrastructure flakes, not real product defects.
24. Use Cucumber/BDD for business workflows. Prefer plain Playwright tests for low-level UI/component checks when those are added.
25. Keep page objects clean: no test data ownership, no scenario logic, and no Cucumber step definitions inside page classes.
26. Organize step files by feature/domain, such as `login.steps.ts`, `user-management.steps.ts`, `payments.steps.ts`, or generated story folders.
27. Use reusable utilities for API calls, date handling, random data, file upload, and DB/API setup.
28. Review automation code like production code: readability, duplication, naming, waits, locators, test independence, and evidence quality must be checked before execution.

## End-to-end flow

### 1. Analyze story and reference knowledge

1. Fetch the current work item from ADO.
2. Inspect title, description, acceptance criteria, comments, attachments, and requirement-bearing linked items.
3. Use the configured reference plan and suite roots recursively. Parent IDs are knowledge roots, not single-node lookups.
4. Use reference suites only for:
   - testcase writing style
   - coverage ideas
   - module behavior patterns
   - realistic step/result phrasing
5. Do not let reference material override the current story.

### 2. Generate manual testcase workbook

1. Write realistic manual cases in the user's style and template.
2. Keep actions and results concrete, verifiable, and story-specific.
3. If the generated cases are not realistic enough for automation, stop and rewrite them before upload.
4. Save the workbook under the project generated Excel folder.
5. Stop for user review.

### 3. Review gate

1. Treat the reviewed workbook as the only upload and automation source.
2. If the user edits the workbook, use that exact file.
3. Do not regenerate silently after review.

### 4. Upload reviewed workbook

1. Parse the workbook row-by-row in the template shape.
2. Preserve action/result pairing exactly.
3. Upload the reviewed cases into the current suite and plan only.
4. Persist testcase ID mapping and upload summary artifacts.

### 5. Generate BDD and POM automation

1. Generate story-specific automation only from the approved workbook and current uploaded ADO case map.
2. Keep feature files business-readable and map them through the framework flow: Feature -> Step Definition -> Page Object -> Playwright Action.
3. Keep traceability by testcase ID across:
   - feature file name
   - scenario title
   - tags
   - manifest
   - traceability index
   - execution summary
4. Reuse the shared framework for pages, fixtures, steps, locators, and utils.
5. Keep generated step definitions thin, typed, and free of direct locators.
6. Add story-specific POM support when the workbook requires it.
7. Persist generated automation code into the project, not only into temporary runtime memory:
   - shared reusable framework code stays under `automation/pages`, `automation/steps`, `automation/fixtures`, `automation/utils`, and `automation/locators`
   - story-specific generated automation stays under the story automation draft folders and generated feature/spec locations
   - manifest and traceability files stay under the per-story `artifacts/stories/<storyId>/automation` folder
8. Store only code that reflects the current approved workbook and current uploaded ADO case map. Do not keep stale generated code as if it belongs to the current run.
9. If a testcase is not fully or safely automatable yet, do not store misleading finished automation for it. Either complete the automation properly or keep it clearly marked as blocked or incomplete in the story artifacts.
10. If inference emits unsupported fallback steps, fix the parser or POM before running Playwright.

### 6. Execute current uploaded ADO cases

1. Execute only the current uploaded ADO testcase set for the current suite and plan.
2. Do not execute from stale manifests or stale workbooks from earlier runs.
3. Prefer headed execution unless the user asks for headless.
4. Drive the browser through Playwright.
5. Use Chrome DevTools MCP only when Playwright needs help for:
   - locator diagnosis
   - DOM inspection
   - console or network failures
   - mismatched rendered state
6. If the run is interrupted, stop all STLCFlow and Playwright child processes before rerun.

### 7. Publish results and artifacts

1. Publish real pass, fail, or blocked outcomes back to ADO.
2. Generate and preserve:
   - execution summary
   - failure summary
   - screenshots
   - traces
   - logs
   - Allure output
3. Preserve post-execution code and artifact state for future reuse and debugging:
   - keep generated features, scenario data, manifests, traceability indexes, and execution result files in the project
   - keep shared framework changes in the framework folders when those changes are part of the fixed automation solution
   - do not delete stable automation code after execution
   - do not overwrite a good story-specific automation set with another story's code
4. Classify failures accurately:
   - product bug
   - automation issue
   - environment or data issue
   - blocked by unsupported workflow state

## Stage selection

- If the user gives only `workItemId`, `suiteId`, and `testPlanId`, start with story analysis and workbook generation.
- If the user asks to continue after review, start from reviewed workbook upload.
- If the user asks to resume after upload, start from automation generation or execution depending on the stored story artifacts.
- If the user asks for status, inspect the story artifact folder first and report what stages are completed versus stale.

## Quality bar

- Do not proceed to automation if testcase generation quality is poor.
- Do not proceed to execution if story-to-case mapping, workbook-to-case mapping, or ADO case mapping is mismatched.
- Do not hide partial completion behind generic summaries.
- If something is unclear, ask the user directly instead of guessing.

## Example triggers

- `Use $stlcflow-end-to-end-qa-automation for work item <workItemId>, suite <suiteId>, and plan <testPlanId>. Start from story analysis and generate the review workbook.`
- `Use $stlcflow-end-to-end-qa-automation to continue the reviewed upload for work item <workItemId> in suite <suiteId> plan <testPlanId>.`
- `Use $stlcflow-end-to-end-qa-automation to execute the current uploaded ADO cases for work item <workItemId> in suite <suiteId> plan <testPlanId> and publish results.`
- `Use $stlcflow-end-to-end-qa-automation to inspect the current STLCFlow status for work item <workItemId>.`
