# Local Files

Use these project-specific paths and conventions for the STLCFlow skill.

## Project root

- `C:\Users\bsaikiran\STLCFlow`

## Key project notes

- `C:\Users\bsaikiran\STLCFlow\README.md`
- `C:\Users\bsaikiran\STLCFlow\requirements.md`
- `C:\Users\bsaikiran\STLCFlow\decisions.md`
- `C:\Users\bsaikiran\STLCFlow\references.md`
- `C:\Users\bsaikiran\STLCFlow\next-steps.md`

## Primary entrypoints

- PowerShell wrapper:
  - `C:\Users\bsaikiran\STLCFlow\STLCCompleteWorkFlow-Playwright.ps1`
- NPM workflow entrypoint:
  - `npm run workflow:playwright -- --story-id=<id> --suite-id=<id> --test-plan-id=<id> ...`
- Story automation generator:
  - `npm run automation:generate-story -- --story-id=<id> --suite-id=<id> --test-plan-id=<id> --approved-workbook="<path>" --project=Cadency`
- TypeScript validation:
  - `npm run check`
- Build:
  - `npm run build`

## Workbook and artifact conventions

- reviewed and generated workbook folder:
  - `C:\Users\bsaikiran\STLCFlow\artifacts\generated-excel`
- per-story artifact root:
  - `C:\Users\bsaikiran\STLCFlow\artifacts\stories\<storyId>`
- upload summary:
  - `C:\Users\bsaikiran\STLCFlow\artifacts\stories\<storyId>\upload-summary.json`
- run state:
  - `C:\Users\bsaikiran\STLCFlow\artifacts\stories\<storyId>\run-state.json`
- execution summary:
  - `C:\Users\bsaikiran\STLCFlow\artifacts\stories\<storyId>\execution-summary.json`

## Automation artifacts

- story automation manifest:
  - `C:\Users\bsaikiran\STLCFlow\artifacts\stories\<storyId>\automation\story-automation-manifest.json`
- traceability index:
  - `C:\Users\bsaikiran\STLCFlow\artifacts\stories\<storyId>\automation\story-automation-traceability-index.json`
- generated story feature files:
  - `C:\Users\bsaikiran\STLCFlow\artifacts\stories\<storyId>\automation\draft\features`
- generated story scenario data:
  - `C:\Users\bsaikiran\STLCFlow\artifacts\stories\<storyId>\automation\draft\data`
- generated Playwright specs:
  - `C:\Users\bsaikiran\STLCFlow\automation\.features-gen`
- execution result files:
  - `C:\Users\bsaikiran\STLCFlow\artifacts\stories\<storyId>\automation\execution-results`
- Allure results:
  - `C:\Users\bsaikiran\STLCFlow\artifacts\allure-results`
- Allure report:
  - `C:\Users\bsaikiran\STLCFlow\artifacts\allure-report`

## Shared framework locations

- shared pages:
  - `C:\Users\bsaikiran\STLCFlow\automation\pages`
- shared steps:
  - `C:\Users\bsaikiran\STLCFlow\automation\steps`
- shared fixtures:
  - `C:\Users\bsaikiran\STLCFlow\automation\fixtures`
- shared utils:
  - `C:\Users\bsaikiran\STLCFlow\automation\utils`
- locator notes:
  - `C:\Users\bsaikiran\STLCFlow\automation\locators`
- generated story data under the framework:
  - `C:\Users\bsaikiran\STLCFlow\automation\data`
- generated story features under the framework:
  - `C:\Users\bsaikiran\STLCFlow\automation\features`

## MCP and config context

- Codex config:
  - `C:\Users\bsaikiran\.codex\config.toml`
- Playwright MCP config:
  - `C:\Users\bsaikiran\STLCFlow\.vscode\playwright-mcp.config.json`

## Existing Cadency workflow skills

Use these only as behavior references when the STLCFlow flow overlaps them:

- `C:\Users\bsaikiran\.codex\skills\cadency-ado-testcase-workflow\SKILL.md`
- `C:\Users\bsaikiran\.codex\skills\cadency-playwright-testcase-workflow\SKILL.md`
